import pygame, sys, random

from pygame.locals import *

width = 800
height = 1000

amount = 8

w = int(width / amount)

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

lines = []

class Line():
    def __init__(self, x):
        self.x = x
        self.y = height + 5
        self.width = w
        self.target = height + 5
        lines.append(self)

    def Show(self, display):
        pygame.draw.rect(display, WHITE, ((self.x,self.y),(self.width,height)),0)
        pygame.draw.rect(display, BLACK, ((self.x,self.y),(self.width,height)),5)

    def SetTarget(self,y):
        self.target = y

    def Update(self):
        if self.y <= self.target:
            self.y += 0.5
            self.target = height + 5
        elif self.target < self.y:
            self.y -= 10

def isBetween(x,y,z):
    return(x < y < z)


def main(display, ss):
    x = 0
    for i in range(amount):
        i = Line(x)
        x += w

    mousedown = False
    count = 0
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True

            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True
                for i in lines:
                    if isBetween(i.x,mx,i.x+w):
                        i.SetTarget(my)

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/piano' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1

        for i in lines:
            i.Update()
        fpsClock.tick(FPS)
    #               Display Screen:

        display.fill(BLACK)

        fontObj = pygame.font.Font('freesansbold.ttf', 60)
        lineA = fontObj.render(str(count), True, BLACK)
        textRectObjA = lineA.get_rect()
        textRectObjA.center = (int(width/2),int(60))
        display.blit(lineA, textRectObjA)

        for i in lines:
            i.Show(display)
        display.blit(back,(0,0))
        pygame.display.update()

