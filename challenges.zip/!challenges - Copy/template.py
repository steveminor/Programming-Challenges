import pygame, sys

from pygame.locals import *


width = 800
height = 1000

#[Delete
DISPLAYSURF = pygame.display.set_mode((width,height))
pygame.display.set_caption('Baflurbulflurp')
pygame.init()
ss = 0
# ]

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

def main(display, ss):
    mousedown = False
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1
                else:
                    print ('elif event.key == '+ str(event.key)+ ':')



        fpsClock.tick(FPS)
    #               Display Screen:

        display.fill(WHITE)
        display.blit(back,(0,0))
        pygame.display.update()

#Delete [
main(DISPLAYSURF,ss)
pygame.quit()
sys.exit
#]