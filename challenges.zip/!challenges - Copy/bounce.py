import pygame, sys,random

from pygame.locals import *


width = 800
height = 1000

fpsClock = pygame.time.Clock()

FPS = 600
radius = 30
gravity = 0.001

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)



class Ball():
    def __init__(self):
        self.x = int(width/2)
        self.y = 0
        self.v = [0.5,1]
        if self.v[1] < -1:
            self.v[1] = -1

        self.color = RED

    def Show(self,display):
        pygame.draw.circle(display, self.color,(int(self.x), int(self.y)),radius-1,0)
        pygame.draw.circle(display, BLACK,(int(self.x), int(self.y)),radius,2)

    def Hit(self, other):
        return(other.ax < self.x and self.x < other.bx and other.ay < self.y + radius and self.y + radius < other.ay+ int(radius/2))

    def Bounce(self):
        self.v[1] = -0.8

    def Left(self):
        self.v[0] = -1


    def Right(self):
        self.v[0] = 1


    def Update(self, others):
        self.x += self.v[0]
        self.y += self.v[1]
        self.v[1] += gravity
        if 1 < self.v[1]:
            self.v[1] = 1

        if width + radius <= self.x:
            self.x = 0 - int(radius/2)

        elif self.x + radius <= 0:
            self.x = width + int(radius/2)

        elif height + radius < self.y:
            self.y = 0 - radius
        for i in others:
            if self.Hit(i) == True and 0 < self.v[1] :
                self.Bounce()
                i.Break()

lines = []
class Line():
    def __init__(self, ax, ay, w, h):
        self.ax = ax
        self.ay = ay
        self.bx = ax + w*3
        self.by = ay + h
        self.width = radius *3
        lines.append(self)

        self.color = BLUE

    def Show(self, display):
        pygame.draw.line(display, self.color, (self.ax,self.ay), (self.bx,self.by), int(radius/2))

    def Break(self):
        if self.color == BLUE:
            self.color = CYAN

        elif self.color == CYAN:
            self.color = GREEN

        elif self.color == GREEN:
            self.color = YELLOW

        elif self.color == YELLOW:
            self.color = RED

        elif self.color == RED:
            self.ax = random.randint(0,width- radius*3)
            self.ay = random.randint(500,700)
            self.bx = self.ax + radius * 3
            self.by = self.ay
            self.color = BLUE





def main(display, ss):
    player = Ball()
    for i in range(3):
        x = random.randint(0,width- radius*3)
        y = random.randint(500,700)
        i = Line(x,y,radius,0)
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/bounce' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1
                elif event.key == 97:
                    player.Left()
                elif event.key == 100:
                    player.Right()
                else:
                    print('elif event.key == ' + str(event.key) + ':')


        mouse = pygame.mouse.get_pos()
        mx = mouse[0]

        player.Update(lines)

        fpsClock.tick(FPS)
    #               Display Screen:

        display.fill(WHITE)
        display.blit(back,(0,0))
        player.Show(display)

        for i in lines:
            i.Show(display)
        pygame.display.update()