import pygame
import sys
import menu
import bamboo
import pressure
import grass
import reverse
import binary
import piano
import tetris
import sinkhole
import bounce

from pygame.locals import *
width = 800
height = 1000
size = int(width/4)

FPS = 600

DISPLAYSURF = pygame.display.set_mode((width,height))
pygame.display.set_caption('')
pygame.init()

fpsClock = pygame.time.Clock()

pygame.mixer.init(frequency=22050, size=-16, channels=100, buffer=700)
pygame.mixer.init()

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

colors = [BLUE,BROWN,CYAN,GRAY,GREEN,LIME,ORANGE,PINK,PURPLE,RED,YELLOW]

def main():
    ss = 0
    down = False
    while True:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print("I can't believe that actually worked.")
                pygame.quit()
                sys.exit()

            elif event.type == MOUSEBUTTONDOWN:
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]

                for i in menu.items:
                    if i.x < mx and mx < i.x + size and i.y < my and my < i.y + size:
                        if i.name =="pressure":
                            pressure.main(DISPLAYSURF,ss)
                        elif i.name =="bamboo":
                            bamboo.main(DISPLAYSURF,ss)

                        elif i.name == "reverse":
                            reverse.main(DISPLAYSURF,ss)

                        elif i.name == "binary":
                            binary.main(DISPLAYSURF,ss)

                        elif i.name == "piano":
                            piano.main(DISPLAYSURF,ss)

                        elif i.name == "tetris":
                            tetris.main(DISPLAYSURF,ss)

                        elif i.name == "sinkhole":
                            sinkhole.main(DISPLAYSURF,ss)

                        elif i.name == "grass":
                            grass.main(DISPLAYSURF,ss)

                        elif i.name == "bounce":
                            bounce.main(DISPLAYSURF,ss)

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/' + str(ss) + '.png'
                    pygame.image.save(DISPLAYSURF,pygame.image.save(DISPLAYSURF,name))
                    ss += 1
                elif event.key == 273:
                    for i in menu.items:
                        i.y -= 200
                elif event.key == 274:
                    for i in menu.items:
                        i.y += 200
                else:
                    print(event.key)

        fpsClock.tick(FPS)

    #               Display Screen:

        DISPLAYSURF.fill(WHITE)

        for i in menu.items:
            i.Show(DISPLAYSURF)

        pygame.display.update()
main()




