import pygame, sys, random

from pygame.locals import *


width = 800
height = 1000

fpsClock = pygame.time.Clock()

FPS = 600
size = 10

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)
colors = [BLUE,BROWN,CYAN,GRAY,GREEN,LIME,ORANGE,PINK,RED,WHITE,YELLOW]

pixels = []
class Pixel():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.color = random.choice(colors)
        pixels.append(self)

    def Show(self, display):
        pygame.draw.rect(display,self.color,((self.x,self.y),(size,size)), 0)

class Hole():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.pull = 2
        self.radius = 1

    def Update(self,pixels):
        grow = True
        self.size = 0
        for i in pixels:
            if self.x < i.x:
                grow = False
                i.x -= self.pull
            elif self.x > i.x:
                grow = False
                i.x += self.pull

            if self.y < i.y:
                grow = False
                i.y -= self.pull
            elif self.y > i.y:
                grow = False
                i.y += self.pull
            if i.x == self.x and self.y == i.y:
                pixels.remove(i)

class Mouse():
    def __init__(self):
        self.x = 0
        self.y = 0
        self.color = RED
    def Show(self, display):
        pygame.draw.rect(display,self.color,((self.x,self.y),(size,size)), 0)

    def Update(self):
        mouse = pygame.mouse.get_pos()
        self.x = mouse[0]
        self.y = mouse[1]


def main(display, ss):

    me = Hole(int(width/2),int(height/2))
    m = Mouse()
    mousedown = False
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/sinkhole' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1
                elif event.key == 32:
                    for i in pixels:
                        i.y+=1
                else:
                    print ('elif event.key == '+ str(event.key)+ ':')

        if mousedown == True:
            mouse = pygame.mouse.get_pos()
            mx = mouse[0]
            my = mouse[1]
            me = Hole(mx,my)
            me.Update(pixels)

        m.Update()

        if len(pixels) == 0:
            x = 0
            y = 0
            for i in range(int(height/size)):
                for j in range(int(width/size)):
                    new = Pixel(x,y)
                    x += size
                x = 0
                y += size
            mousedown = False
        fpsClock.tick(FPS)
    #               Display Screen:

        display.fill(BLACK)

        for i in pixels:
            i.Show(display)
        m.Show(display)

        display.blit(back,(0,0))
        pygame.display.update()