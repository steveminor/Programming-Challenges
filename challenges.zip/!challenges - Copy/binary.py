import pygame, sys, random

from pygame.locals import *


width = 800
height = 1000

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

screen = []

class Number():
    def __init__(self,x,y):
        self.x = x
        self.y = y
        self.char = random.choice(['0','1'])
        screen.append(self)

    def Show(self, display):
        fontObj = pygame.font.Font('freesansbold.ttf', 32)
        lineA = fontObj.render(self.char, True, GREEN)
        textRectObjA = lineA.get_rect()
        textRectObjA.center = (self.x,self.y)
        display.blit(lineA, textRectObjA)

    def Update(self):
        self.y += 32
        if self.y > height + 32:
            screen.remove(self)

def main(display, ss):
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            elif event.type == MOUSEBUTTONDOWN:
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                pass

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/binary' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1
        mouse = pygame.mouse.get_pos()
        mx = mouse[0]
        my = mouse[1]
        for i in range(3):
            i = Number(mx,my)
            mx += 32
        for i in screen:
            i.Update()

        fpsClock.tick(FPS)
    #               Display Screen:

        display.fill(BLACK)

        for i in screen:
            i.Show(display)

        display.blit(back,(0,0))
        pygame.display.update()

