import pygame, sys, random

from pygame.locals import *

width = 800
height = 1000

w = 10

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

stalks = []
clippings = []

class Bamboo():
    def __init__(self, x):
        self.x = x
        self.y = height
        stalks.append(self)

    def Show(self, display):
        pygame.draw.line(display, GREEN, (self.x,self.y), (self.x,height), w)
        pygame.draw.line(display, LIME, (self.x,self.y), (self.x,height), 1)

    def Break(self, y):
        child = Clipping(self,y)
        self.y = y

    def Update(self):
        self.y -= 0.5

class Clipping():
    def __init__(self, parent,y):
        x = random.choice([-10,10])
        self.x = parent.x +x
        self.y = parent.y
        self.y2 = y
        stalks.append(self)
        self.v = 1

    def Show(self, display):
        pygame.draw.line(display, GREEN, (self.x,self.y), (self.x,self.y2), w)
        pygame.draw.line(display, LIME, (self.x,self.y), (self.x,self.y2), 1)

    def Break(self, y):
        if self.y - self.y2 >= 10:
            child = Clipping(self,y)
            self.y = y

    def Update(self):
        self.y += self.v
        self.y2 += self.v
        self.v += 0.1
        self.x += 0.1
        if self.y > height:
            stalks.remove(self)

def main(display, ss):
    x = 0
    for i in range(27):
        i = Bamboo(x)
        x += 30

    cutting = False
    count = 0
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print("I can't believe that actually worked.")
                pygame.quit()
                sys.exit()

            elif event.type == MOUSEBUTTONDOWN:
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True
                cutting = True

            elif event.type == MOUSEBUTTONUP:
                cutting = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/bamboo' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1

        if cutting == True:
            mouse = pygame.mouse.get_pos()
            mx = mouse[0]
            my = mouse[1]
            for i in stalks:
                if i.x < mx and mx < i.x + w:
                    i.Break(my)
                    count += 1

        for i in stalks:
            i.Update()

        for i in clippings:
            i.Update()
        fpsClock.tick(FPS)
    #               Display Screen:

        display.fill(WHITE)

        fontObj = pygame.font.Font('freesansbold.ttf', 60)
        lineA = fontObj.render(str(count), True, BLACK)
        textRectObjA = lineA.get_rect()
        textRectObjA.center = (int(width/2),int(60))
        display.blit(lineA, textRectObjA)

        for i in stalks:
            i.Show(display)

        for i in clippings:
            i.Show(display)

        display.blit(back,(0,0))
        pygame.display.update()
