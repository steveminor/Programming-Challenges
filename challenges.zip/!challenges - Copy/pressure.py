import pygame, sys

from pygame.locals import *

width = 800
height = 1000

fpsClock = pygame.time.Clock()

FPS = 600

background = pygame.image.load("pressure/background.png")
RED = pygame.image.load("pressure/red.png")
back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)

def main(display, ss):
    weight = 0
    mousedown = False
    y = 800
    v = 1
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                print("I can't believe that actually worked.")
                pygame.quit()
                sys.exit()

            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/pressure' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1

        print(mousedown)
        if mousedown == True:
            weight += 1
            v = 1
        else:
            if weight >0:
                weight -= v
                v += 1
            else:
                v = 1
        y = height - weight

        if y < 0:
            y = 0

        if weight< 0:
            weight = 0

        fpsClock.tick(FPS)
    #               Display Screen:

        display.blit(background,(0,0))
        display.blit(RED,(0,y))

        fontObj = pygame.font.Font('freesansbold.ttf', 60)
        lineA = fontObj.render(str(weight), True, BLACK)
        textRectObjA = lineA.get_rect()
        textRectObjA.center = (int(width/2),int(height/2))
        display.blit(lineA, textRectObjA)

        display.blit(back,(0,0))
        pygame.display.update()
