import pygame

items = []

width = 800
height = 1000

x = 0
y = 0

class Item():
    def __init__(self,name,x,y):
        self.name = name
        self.x = x
        self.y = y

        image = 'menu/' + name + '.png'
        self.image = pygame.image.load(image)

        items.append(self)

    def Show(self, display):
        display.blit(self.image,(self.x,self.y))

programs = ['pressure','bamboo','reverse','binary','piano','tetris','sinkhole','grass','bounce']
programss =[]
for i in range(1000):
    for j in programs:
        programss.append(j)

x = 0
y = 0

for i in programs:
    new = Item(i,x,y)
    x += 200
    if x >= width:
        x = 0
        y += 200
