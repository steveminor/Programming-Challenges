import pygame, sys

from pygame.locals import *

width = 800
height = 1000

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

front = []
radius = 30
class Circle():
    def __init__(self,x,y,color):
        self.x = x
        self.y = y

        self.color = color

        self.radius = radius

    def Clicked(self, mx, my):
        return(self.x - self.radius < mx and mx < self.x + radius and self.y - self.radius < my and my < self.y + radius)

    def Change(self, up, down):

        if self.color == LIME:
            if down == True:
                self.color = GREEN
                self.y += int(radius/2)

        else:
            if up == True:
                self.color = LIME
                self.y -= int(radius/2)

    def Show(self, display):
        pygame.draw.circle(display, self.color, (self.x,self.y), self.radius, 0)
        pygame.draw.circle(display, BLACK, (self.x,self.y), self.radius, 1)



def main(display, ss):
    x = 0 - int(radius/2)
    y = 0 - int(radius/2)

    for h in range(40):
        for i in range(30):
            i = Circle(x,y,LIME)
            front.append(i)
            x += radius
        if h % 2 == 0:
            x = 0 - radius
        else:
            x = 0 - int(radius/2)
        y += radius

    up = False
    down = False
    y = 0

    mousedown = False

    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/reverse' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1
        mouse = pygame.mouse.get_pos()
        mx = mouse[0]
        my = mouse[1]
        if my < y:
            up = True
        else:
            up = False
        if my > y:
            down = True
        else:
            down = False

        y = my

        if mousedown == True:
            for i in front:
                if i.Clicked(mx, my):
                    i.Change(up,down)

        fpsClock.tick(FPS)
    #               Display Screen:
        for i in front:
            i.Show(display)
        display.blit(back,(0,0))
        pygame.display.update()
