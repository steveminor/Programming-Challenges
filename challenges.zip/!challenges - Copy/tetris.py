import pygame, sys, random

from pygame.locals import *


width = 800
height = 1000

w = int(height/20)

colums = width/w

rows = 20

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")
background = pygame.image.load("tetris/bg.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

class Block():
    def __init__(self,color):
        self.color = color
        self.w = w

    def Show(self, display):
        pygame.draw.rect(display,self.color,((self.x,self.y),(self.w,self.w)), 0)
        pygame.draw.rect(display,BLACK,((self.x,self.y),(self.w,self.w)), 1)

class Tetra():
    colors = [RED, GREEN, BLUE, ORANGE, YELLOW, PINK,CYAN]
    cordsset1 =[
        [  0, 0 ,0 - w, 0,  0, 0 + w,  0 + w,0 + w],
        [  0, 0,0 - w, 0,  0,0 - w, 0 + w,0 - w],
        [  0, 0,0 - w, 0, 0 + w, 0, 0 - w,0 + w],
        [  0, 0, 0 + w, 0,0 - w, 0, 0 - w,0 - w],
        [  0, 0, 0 + w, 0,  0, 0 - w, 0 + w,0 - w],
        [  0, 0,  0, 0 + w, 0 - w, 0,0 + w, 0],
        [ 0, 0, 0 - w,0, 0 - w*2, 0,  0 + w, 0]]

    cordsset2 =[
        [  0, 0,0 - w, 0,  0,0 - w,0 - w,0 + w],
        [  0, 0,0 + w, 0,0 + w,0 + w,  0,0 - w],
        [  0, 0,  0,0 + w,  0,0 - w,0 - w,0 - w],
        [0, 0, 0, 0 + w, 0, 0 - w, 0 + w, 0 - w],
        [  0, 0, 0 + w, 0,  0, 0 + w, 0 + w,0 + w],
        [  0, 0,0 - w, 0,  0,0 - w,  0,0 + w],
        [  0, 0,  0, 0 + w,  0, 0 - w,  0, 0 - w * 2]]

    cordsset3 =[
        [  0, 0, 0 + w, 0,0 - w,0 - w, 0,0 - w],
        [  0, 0,  0,0 + w,0 - w,0 + w, 0 + w, 0],
        [  0, 0, 0 + w, 0,0 - w, 0, 0 + w,0 - w],
        [0, 0, 0 - w, 0, 0 + w, 0, 0 + w, 0 + w],
        [  0, 0, 0 + w, 0,  0, 0 + w, 0 + w,0 + w],
        [  0, 0,0 - w, 0,  0 + w,0,  0,0 - w],
        [  0, 0, 0 + w, 0,0 + w * 2, 0, 0 - w, 0]]
    cordsset4 =[
        [  0, 0, 0 + w, 0, 0 + w,0 - w,  0, 0 + w],
        [  0, 0,0 - w, 0,0 - w,0 - w,  0,0 + w],
        [  0, 0,  0,0 - w,  0,0 + w, 0 + w,0 + w],
        [  0, 0,  0,0 - w,  0,0 + w,0 - w,0 + w],
        [  0, 0, 0 + w, 0,  0, 0 + w, 0 + w,0 + w],
        [  0, 0, 0 + w, 0,  0,0 + w,  0,0 - w],
        [  0, 0,  0,0 - w,  0, 0 + w,  0, 0 + w * 2]]

    cordsset =[cordsset1,cordsset2,cordsset3,cordsset4]

    def __init__(self,ray):
        self.type = random.randint(0,6)
        self.ray = []
        self.color = Tetra.colors[self.type]

        for i in range(4):
            i = Block(self.color)
            i.x = int(width/2)-w
            i.y = w * 2
            i.angle = -90
            self.ray.append(i)

        self.cordsset = Tetra.cordsset[0]
        self.cords = self.cordsset[self.type]
        x = 0
        y = 1
        for i in self.ray:
            i.x += self.cords[x]
            i.y += self.cords[y]
            x += 2
            y += 2

    def rotate(self):
        if self.cordsset == Tetra.cordsset[0]:
            self.cordsset = Tetra.cordsset[1]
        elif self.cordsset == Tetra.cordsset[1]:
            self.cordsset = Tetra.cordsset[2]
        elif self.cordsset == Tetra.cordsset[2]:
            self.cordsset = Tetra.cordsset[3]
        elif self.cordsset == Tetra.cordsset[3]:
            self.cordsset = Tetra.cordsset[0]

        for i in self.ray:
            i.x = self.ray[0].x
            i.y = self.ray[0].y

        self.cords = self.cordsset[self.type]
        x = 0
        y = 1
        for i in self.ray:
            i.x += self.cords[x]
            i.y += self.cords[y]
            x += 2
            y += 2


    def rotateback(self):
        if self.cordsset == Tetra.cordsset[0]:
            self.cordsset = Tetra.cordsset[3]
        elif self.cordsset == Tetra.cordsset[1]:
            self.cordsset = Tetra.cordsset[0]
        elif self.cordsset == Tetra.cordsset[2]:
            self.cordsset = Tetra.cordsset[1]
        elif self.cordsset == Tetra.cordsset[3]:
            self.cordsset = Tetra.cordsset[2]

        for i in self.ray:
            i.x = self.ray[0].x
            i.y = self.ray[0].y

        self.cords = self.cordsset[self.type]
        x = 0
        y = 1
        for i in self.ray:
            i.x += self.cords[x]
            i.y += self.cords[y]
            x += 2
            y += 2

    def addtetra(self, solids):
        for i in self.ray:
            solids.append(i)
        for i in self.ray:
            self.ray.remove(i)
        return solids


def main(display, ss):
    solids = []
    ray = getray(3)
    tetra = Tetra(ray)
    cleared = 0
    timer = 0
    freeze = 0
    done = False
    while done == False:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True
            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/tetris' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1
            # Space Key
                if event.key == 32:
                    tetra.rotate()
                    for i in tetra.ray:
                        if i.x < 5 or 185 < i.x:
                            tetra.rotateback()
            # Enter Key
                elif event.key == 13:
                    solids = clearrow(solids,386)

                elif event.key ==273:
                    stop = False
                    for i in tetra.ray:
                        if i.y == 0:
                            stop = True
                    if stop == False:
                        for i in tetra.ray:
                            i.y -= w

                elif event.key == 274:
                    stop = False
                    for i in tetra.ray:
                        if i.y == height - w:
                            stop = True
                    if stop == False:
                        for i in tetra.ray:
                            i.y += w
                elif event.key == 276:
                    stop = False
                    for i in tetra.ray:
                        if i.x == 0:
                            stop = True
                    if stop == False:
                        for i in tetra.ray:
                            i.x -= w
                elif event.key == 275:
                    stop = False
                    for i in tetra.ray:
                        if i.x == width - w:
                            stop = True
                    if stop == False:
                        for i in tetra.ray:
                            i.x += w
                elif event.key == 9:
                    for i in tetra.ray:
                        print(i.x,i.y)
                else:
                    print ('elif event.key == '+ str(event.key)+ ':')

        tetra.stop = False
        for i in tetra.ray:
            if i.y == height-w:
                tetra.stop = True
            for j in solids:
                if i.x == j.x and i.y == j.y-w:
                    tetra.stop = True
        if tetra.stop == True:
            solids = tetra.addtetra(solids)
            tetra = Tetra(ray)

        columns = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

        y = 0
        index = 0
        for i in columns:
            for j in solids:
                if j.y == y:
                    columns[index] +=1
            y += w
            index += 1
        y = 0
        for i in columns:
            if i == 16:
                clearrow(solids,y)
                cleared += 1
            y += w

        go = False
        for i in solids:
            if i.y <= w*3:
                go = True

        if go == True:
            solids = []
            cleared = 0

        display.blit(background,(0,0))


        for i in tetra.ray:
            i.Show(display)

        for i in solids:
            i.Show(display)


        fontObj = pygame.font.Font('freesansbold.ttf', 40)
        lineA = fontObj.render(str(cleared), True, ( 0,  0, 0))
        textRectObjA = lineA.get_rect()
        textRectObjA.center = (width - 40,40)
        display.blit(lineA, textRectObjA)

        pygame.draw.line(display,BLACK,(0,w*4),(width,w*4),3)
        display.blit(back,(0,0))
        pygame.display.update()
        fpsClock.tick(FPS)

def getray(count):
    output = []
    for i in range(count):
        output.append(random.randint(0,6))
    return output

def getset(ray):
    output = ray[0]
    ray.remove(output)
    ray.append(random.randint(0,6))
    return output

def clearrow(ray, y):
    for h in range(16):
        for i in ray:
            if i.y == y:
                ray.remove(i)
    for i in ray:
        if i.y < y:
            i.y += w
    return ray
