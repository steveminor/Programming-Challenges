import pygame, sys

from pygame.locals import *


width = 800
height = 1000

fpsClock = pygame.time.Clock()

FPS = 600

back = pygame.image.load("back.png")

BLACK = (  0,  0,  0)
BLUE  = (  0,  0,255)
BROWN = (127,57,0)
CYAN  = (  0,255,255)
GRAY = (127,127,127)
GREEN = (  0,136,  0)
LIME  = ( 76,255,  0)
ORANGE= (255, 89,  0)
PINK   = (255,  0,220)
PURPLE= (178,  0,255)
RED   = (255,  0,  0)
WHITE = (255,255,255)
YELLOW= (255,255,  0)

squares = []

class Ball():
    def __init__(self):
        self.x = int(width/2)
        self.y = int(height/2)
        self.r = 50
        self.direction = 'None'
        self.vx = 0
        self.vy = 0
        self.up = False
        self.down = False
        self.left = False
        self.right = False

    def At(self, square):
        return(
                square.x < self.x - self.r and
                self.x - self.r < square.x2 and
                square.y < self.y - self.r and
                self.y - self.r < square.y2 or

                square.x < self.x - self.r and
                self.x - self.r < square.x2 and
                square.y < self.y + self.r and
                self.y - self.r < square.y2 or

                square.x < self.x + self.r and
                self.x - self.r < square.x2 and
                square.y < self.y - self.r and
                self.y - self.r < square.y2 or

                square.x < self.x + self.r and
                self.x - self.r < square.x2 and
                square.y < self.y + self.r and
                self.y - self.r < square.y2
              )

    def Show(self,display):
        pygame.draw.circle(display, RED,(int(self.x),int(self.y)),self.r,0)
        pygame.draw.circle(display, GRAY,(int(self.x),int(self.y)),int(10),0)
        pygame.draw.circle(display, BLACK,(int(self.x),int(self.y)),self.r,1)

    def Update(self):
        #Increase Velocity
        if self.up == True and self.vy > -2:
                self.vy -= 0.02

        if self.down == True and self.vy < 2:
            self.vy += 0.02

        if self.left == True and self.vx > -2:
            self.vx -= 0.02

        if self.right == True and self.vx < 2:
            self.vx += 0.02

        #Decrease Velocity
        if 0 < self.vx:
            self.vx -= 0.01

        if self.vx < 0:
            self.vx += 0.01

        if 0 < self.vy:
            self.vy -= 0.01

        if self.vy < 0:
            self.vy +=0.01


        if self.vy> 2:
            vy = 2
        #Move
        self.x += self.vx
        self.y += self.vy

        #Check Bounderies
        if self.x -self.r < 0:
            self.x = 0 + self.r
            self.vx *= -1
        if self.y-self.r < 0:
            self.y = 0 + self.r
            self.vy *= -1
        elif width < self.x + self.r:
            self.x = width - self.r
            self.vx *= -1
        elif height - self.r < self.y:
            self.y = height - self.r
            self.vy *= -1

class Square:
    def __init__(self, x, y, w):
        self.x = x
        self.x2 = x + w
        self.y = y
        self.y2 = y + w
        self. w = w
        self.color = GREEN



    def Cut(self):
        self.color = LIME
    def Grow(self):
        self.color = GREEN

    def Show(self, display):
        pygame.draw.rect(display,self.color,((self.x,self.y),(self.w,self.w)), 0)
        pygame.draw.rect(display,BLACK,((self.x,self.y),(self.w,self.w)), 1)




def main(display, ss):
    x = 0
    y = 0
    w = 50
    for i in range(int(height/w)):
        for j in range(int(width/w)):
            j = Square(x,y,w)
            squares.append(j)
            x += w
        y += w
        x = 0

    player = Ball()
    amount = len(squares)
    count = 0
    done = False
    while done == False:
    #               Check for events:                                              #
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                done = True
            elif event.type == MOUSEBUTTONDOWN:
                mousedown = True
                mouse = pygame.mouse.get_pos()
                mx = mouse[0]
                my = mouse[1]
                if 0 < mx and mx < 100 and 0 < my and my < 100:
                    done = True

            elif event.type == MOUSEBUTTONUP:
                mousedown = False

            elif event.type== KEYDOWN:
                if event.key == 282:
                    name = 'ss/grass' + str(ss) + '.png'
                    pygame.image.save(display,pygame.image.save(display,name))
                    ss += 1

                elif event.key == 119:
                    player.up = True
                elif event.key == 115:
                    player.down = True
                elif event.key == 97:
                    player.left = True
                elif event.key == 100:
                    player.right = True

            elif event.type== KEYUP:
                if event.key == 119:
                    player.up = False
                elif event.key == 115:
                    player.down = False
                elif event.key == 97:
                    player.left = False
                elif event.key == 100:
                    player.right = False

        player.Update()


        for square in squares:
            if player.At(square) == True:
                if square.color == GREEN:
                    square.Cut()
                    amount -= 1

        if  amount <= 0:
            count += 1
            for i in squares:
                i.Grow()
            amount = len(squares)
        fpsClock.tick(FPS)

    #               Display Screen:
        for i in squares:
            i.Show(display)


        player.Show(display)
        fontObj = pygame.font.Font('freesansbold.ttf', 60)
        lineA = fontObj.render(str(count), True, BLACK)
        textRectObjA = lineA.get_rect()
        textRectObjA.center = (int(width/2),int(60))
        display.blit(lineA, textRectObjA)

        display.blit(back,(x,0))
        pygame.display.update()